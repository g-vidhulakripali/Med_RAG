import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # LLM Configuration
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "AIzaSyB-_9BIOUBoayeMJ8F6cvkaz6OIuh63PIo")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    
    # Model Configuration
    DEFAULT_MODEL = "gemini-1.5-pro"  # Google Gemini model (primary)
    FALLBACK_MODEL = "gpt-3.5-turbo"  # OpenAI fallback
    OLLAMA_MODEL = "mistral"  # Ollama Mistral model (local fallback)
    
    # Ollama Configuration
    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    
    # Vector Store Configuration
    VECTOR_STORE_TYPE = "chroma"  # Options: chroma, faiss, qdrant
    EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
    
    # Document Processing
    CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200
    MAX_TOKENS = 4000
    
    # System Configuration
    TEMPERATURE = 0.1
    TOP_K_RETRIEVAL = 5
    CONFIDENCE_THRESHOLD = 0.7
    
    # File Paths
    DATA_DIR = "Data"
    VECTOR_STORE_DIR = "vector_store"
    LOGS_DIR = "logs"
    
    @classmethod
    def validate_config(cls):
        """Validate that required configuration is present"""
        if not cls.GOOGLE_API_KEY and not cls.OPENAI_API_KEY:
            # If no API keys, we'll rely on Ollama as the primary option
            print("Warning: No API keys provided. Will use Ollama (local) as primary LLM.")
        return True
